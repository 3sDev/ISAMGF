<?php

namespace App\Libs;

class Urlupload
{
    // protected static $uploads = [
    //     'url_upload' => 'https://smartschools.tn/university/public/upload',
    //     'url_server' => 'https://smartschools.tn/university/public/api',
    // ];

    public function getLinks()
    {
        //return ['https://smartschools.tn/university/public/upload'];
		return ['https://isamgafsa.tn/university/public/upload'];
    }

}
