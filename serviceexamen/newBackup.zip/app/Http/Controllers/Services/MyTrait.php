<?php

namespace App\Http\Controllers\Services;

/**
 * 
 */
trait MyTrait
{
    //Share method
    function getUrlServer()
    {
       return 'http://127.0.0.1:8080/api';
       //return 'https://smartschools.tn/university/public/api';
	   //return 'https://isamgafsa.tn/university/public/api';
    }
}

?>